INSERT INTO actividad (nombre, entrenador, dia, turno) VALUES
('Yoga', 'Ana', 'LUNES', 'MAÑANA'),
('Pilates', 'Carlos', 'MARTES', 'TARDE'),
('CrossFit', 'Juan', 'MIERCOLES', 'NOCHE'),
('Zumba', 'María', 'JUEVES', 'TARDE'),
('Natación', 'Pedro', 'VIERNES', 'MAÑANA'),
('Kickboxing', 'Laura', 'LUNES', 'TARDE'),
('Spinning', 'Roberto', 'MARTES', 'MAÑANA'),
('Pilates', 'Carolina', 'MIERCOLES', 'TARDE'),
('Yoga', 'Ana', 'JUEVES', 'NOCHE'),
('CrossFit', 'Juan', 'VIERNES', 'TARDE');


INSERT INTO entrenador (nombre, apellido, edad, idActividad) VALUES
('Ana', 'García', 30, 1),
('Carlos', 'López', 35, 2),
('Juan', 'Pérez', 28, 3),
('María', 'Martínez', 32, 4),
('Pedro', 'Rodríguez', 27, 5),
('Laura', 'Hernández', 31, 6),
('Roberto', 'Gómez', 29, 7),
('Carolina', 'Sánchez', 34, 8),
('Ana', 'García', 30, 9),
('Juan', 'Pérez', 28, 10);


INSERT INTO socio (nombre, apellido, edad, idActividad) VALUES
('Luis', 'González', 25, 1),
('Sofía', 'López', 23, 2),
('Pedro', 'Ramírez', 40, 3),
('Ana', 'Fernández', 32, 4),
('Marta', 'Soto', 29, 5),
('David', 'Torres', 27, 6),
('Carolina', 'Rojas', 33, 7),
('Javier', 'Pérez', 28, 8),
('Laura', 'Hernández', 31, 9),
('Carlos', 'Vargas', 26, 10),
('María', 'Gómez', 24, 1),
('Roberto', 'Martínez', 30, 2),
('Juan', 'Sánchez', 27, 3),
('Lucía', 'García', 29, 4),
('Diego', 'Pérez', 26, 5),
('Paula', 'López', 31, 6),
('Andrés', 'Ramírez', 33, 7),
('Elena', 'Fernández', 35, 8),
('Gabriel', 'Soto', 24, 9),
('Natalia', 'Torres', 28, 10),
('Luisa', 'González', 26, 1),
('José', 'López', 25, 2);

