package arg.org.centro8.curso.java.club.test;

import arg.org.centro8.curso.java.club.entities.Socio;
import arg.org.centro8.curso.java.club.entities.Entrenador;
import arg.org.centro8.curso.java.club.entities.Actividad;
import arg.org.centro8.curso.java.club.enums.Dia;
import arg.org.centro8.curso.java.club.enums.Turno;
import arg.org.centro8.curso.java.club.repositories.EntrenadorRepository;
import arg.org.centro8.curso.java.club.repositories.SocioRepository;
import arg.org.centro8.curso.java.club.repositories.ActividadRepository;

public class TestRepository {
   public static void main(String[] args) {
        ActividadRepository a=new ActividadRepository();
        Actividad actividad=new Actividad("Yoga", "Ana", Dia.LUNES, Turno.MAÑANA);
        a.save(actividad);
        System.out.println(actividad);

        a.getAll().forEach(System.out::println);
        System.out.println(" ");
        System.out.println("******************************");
        System.out.println(a.getById(1));
        System.out.println("******************************");
        //a.getLikeNombre("Yoga").forEach(System.out::println);

        SocioRepository sr=new SocioRepository();
        Socio socio=new Socio("Sofia", "Lopez", 23, 2);
        sr.save(socio);
        System.out.println(socio);

        System.out.println("******************************");
        sr.getAll().forEach(System.out::println);
        System.out.println("******************************");
        System.out.println(sr.getById(2));
        System.out.println("******************************");
        sr.getLikeApellido("Lop").forEach(System.out::println);

        EntrenadorRepository er=new EntrenadorRepository();
        Entrenador entrenador=new Entrenador("Ana", "Garcia", 30, 1);
        er.save(entrenador);
        System.out.println(entrenador);

        System.out.println("******************************");
        er.getAll().forEach(System.out::println);
        System.out.println("******************************");
        System.out.println(er.getById(1));
        System.out.println("******************************");
        er.getLikeApellido("Ga").forEach(System.out::println);
        
        
   } 
}






