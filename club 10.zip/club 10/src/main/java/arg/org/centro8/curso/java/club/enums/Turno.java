package arg.org.centro8.curso.java.club.enums;

public enum Turno {
    MAÑANA,
    TARDE,
    NOCHE
}
